# Santa's Magic Sack

- Category      : Web
- Author        : Elweth
- Difficulty    : Medium

You dreamt it, we did it. The shop for the famous Route-Mi platform is now available. And guess what? We're offering you a €5 discount voucher, so enjoy yourself, it's for us.

# Deploy

```bash
docker compose up --build
```
